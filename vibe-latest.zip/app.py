import os
import secrets
import sqlite3
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path

from flask import Flask, abort, flash, g, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("VIBE_DATABASE", BASE_DIR / "vibe.db"))
app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("VIBE_SECRET_KEY", "dev-only-change-this-secret-before-deployment"),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("VIBE_HTTPS", "0") == "1",
    MAX_CONTENT_LENGTH=1 * 1024 * 1024,
)

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL COLLATE NOCASE UNIQUE,
    email TEXT NOT NULL COLLATE NOCASE UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    body TEXT NOT NULL CHECK(length(body) BETWEEN 1 AND 1000),
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS likes (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    PRIMARY KEY(user_id, post_id)
);
CREATE TABLE IF NOT EXISTS comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    body TEXT NOT NULL CHECK(length(body) BETWEEN 1 AND 500),
    created_at TEXT NOT NULL
);
"""

def now_iso():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

@app.cli.command("init-db")
def init_db_command():
    """Create database tables."""
    with app.app_context():
        get_db().executescript(SCHEMA)
        get_db().commit()
    print(f"Database initialized at {DB_PATH}")

@app.before_request
def ensure_csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = secrets.token_urlsafe(32)
    if request.method == "POST":
        sent = request.form.get("csrf_token", "")
        if not sent or not secrets.compare_digest(sent, session["csrf_token"]):
            abort(400, description="Security token missing or expired. Refresh the page and try again.")

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            flash("Please log in to do that.", "info")
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped

@app.context_processor
def inject_globals():
    user = None
    if session.get("user_id"):
        user = get_db().execute("SELECT id, username, email FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    return {"current_user": user, "csrf_token": session.get("csrf_token", "")}

@app.route("/")
def index():
    if session.get("user_id"):
        return redirect(url_for("feed"))
    return render_template("landing.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user_id"):
        return redirect(url_for("feed"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if not (3 <= len(username) <= 24) or not all(c.isalnum() or c in "_-" for c in username):
            flash("Username must be 3–24 characters and use only letters, numbers, _ or -.", "error")
        elif len(email) > 254 or "@" not in email or "." not in email.rsplit("@", 1)[-1]:
            flash("Enter a valid email address.", "error")
        elif len(password) < 8:
            flash("Use a password with at least 8 characters.", "error")
        else:
            db = get_db()
            try:
                cur = db.execute(
                    "INSERT INTO users(username, email, password_hash, created_at) VALUES (?, ?, ?, ?)",
                    (username, email, generate_password_hash(password), now_iso()),
                )
                db.commit()
                session.clear()
                session["user_id"] = cur.lastrowid
                session["csrf_token"] = secrets.token_urlsafe(32)
                flash("Welcome to Vibe! Your account has been created.", "success")
                return redirect(url_for("feed"))
            except sqlite3.IntegrityError:
                flash("That username or email is already registered.", "error")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("feed"))
    if request.method == "POST":
        identity = request.form.get("identity", "").strip()
        password = request.form.get("password", "")
        user = get_db().execute(
            "SELECT * FROM users WHERE username = ? OR email = ?", (identity, identity.lower())
        ).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            session["csrf_token"] = secrets.token_urlsafe(32)
            flash("You're logged in. Welcome back!", "success")
            return redirect(url_for("feed"))
        flash("Invalid username/email or password.", "error")
    return render_template("auth.html", mode="login")

@app.post("/logout")
@login_required
def logout():
    session.clear()
    flash("You have been logged out.", "info")
    return redirect(url_for("index"))

@app.route("/feed")
@login_required
def feed():
    db = get_db()
    rows = db.execute("""
        SELECT p.id, p.body, p.created_at, u.id AS author_id, u.username,
               (SELECT COUNT(*) FROM likes l WHERE l.post_id = p.id) AS like_count,
               EXISTS(SELECT 1 FROM likes l WHERE l.post_id = p.id AND l.user_id = ?) AS liked
        FROM posts p JOIN users u ON u.id = p.user_id
        ORDER BY p.id DESC LIMIT 100
    """, (session["user_id"],)).fetchall()
    comments = {}
    if rows:
        ids = [row["id"] for row in rows]
        placeholders = ",".join("?" for _ in ids)
        comment_rows = db.execute(f"""
            SELECT c.id, c.post_id, c.body, c.created_at, u.username
            FROM comments c JOIN users u ON u.id = c.user_id
            WHERE c.post_id IN ({placeholders}) ORDER BY c.id ASC
        """, ids).fetchall()
        for comment in comment_rows:
            comments.setdefault(comment["post_id"], []).append(comment)
    return render_template("feed.html", posts=rows, comments=comments)

@app.post("/posts")
@login_required
def create_post():
    body = request.form.get("body", "").strip()
    if not body:
        flash("Write something before posting.", "error")
    elif len(body) > 1000:
        flash("Posts must be 1,000 characters or fewer.", "error")
    else:
        get_db().execute("INSERT INTO posts(user_id, body, created_at) VALUES (?, ?, ?)",
                         (session["user_id"], body, now_iso()))
        get_db().commit()
        flash("Your post is live!", "success")
    return redirect(url_for("feed"))

@app.post("/posts/<int:post_id>/like")
@login_required
def toggle_like(post_id):
    db = get_db()
    post = db.execute("SELECT id FROM posts WHERE id = ?", (post_id,)).fetchone()
    if not post:
        abort(404)
    existing = db.execute("SELECT 1 FROM likes WHERE user_id = ? AND post_id = ?", (session["user_id"], post_id)).fetchone()
    if existing:
        db.execute("DELETE FROM likes WHERE user_id = ? AND post_id = ?", (session["user_id"], post_id))
    else:
        db.execute("INSERT INTO likes(user_id, post_id, created_at) VALUES (?, ?, ?)", (session["user_id"], post_id, now_iso()))
    db.commit()
    return redirect(url_for("feed"))

@app.post("/posts/<int:post_id>/comments")
@login_required
def add_comment(post_id):
    body = request.form.get("body", "").strip()
    db = get_db()
    if not db.execute("SELECT id FROM posts WHERE id = ?", (post_id,)).fetchone():
        abort(404)
    if not body:
        flash("Comment cannot be empty.", "error")
    elif len(body) > 500:
        flash("Comments must be 500 characters or fewer.", "error")
    else:
        db.execute("INSERT INTO comments(user_id, post_id, body, created_at) VALUES (?, ?, ?, ?)",
                   (session["user_id"], post_id, body, now_iso()))
        db.commit()
    return redirect(url_for("feed"))

@app.route("/profile")
@login_required
def profile():
    db = get_db()
    user = db.execute("SELECT id, username, email, created_at FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    posts = db.execute("SELECT p.*, (SELECT COUNT(*) FROM likes l WHERE l.post_id=p.id) AS like_count FROM posts p WHERE user_id=? ORDER BY id DESC", (session["user_id"],)).fetchall()
    return render_template("profile.html", profile_user=user, posts=posts)

if __name__ == "__main__":
    with app.app_context():
        get_db().executescript(SCHEMA)
        get_db().commit()
    app.run(debug=os.environ.get("VIBE_DEBUG", "0") == "1")

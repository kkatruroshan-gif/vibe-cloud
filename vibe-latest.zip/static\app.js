// ═══════════════════════════════════════════════════════════════════════════
// Vibe — Animations powered by anime.js
// All important actions also work without JavaScript (progressive enhancement).
// ═══════════════════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {

  // ─── Topbar Entrance ────────────────────────────────────────────────────
  anime({
    targets: '.topbar',
    translateY: [-30, 0],
    opacity: [0, 1],
    duration: 650,
    easing: 'easeOutCubic',
  });


  // ─── Hero Section — Staggered Timeline ──────────────────────────────────
  const heroEls = document.querySelectorAll(
    '.hero .eyebrow, .hero h1, .hero > p, .hero-actions, .hero-note'
  );
  if (heroEls.length) {
    anime({
      targets: heroEls,
      translateY: [32, 0],
      opacity: [0, 1],
      duration: 800,
      delay: anime.stagger(110, { start: 200 }),
      easing: 'easeOutCubic',
    });
  }


  // ─── Auth Card Scale-In ─────────────────────────────────────────────────
  const authCard = document.querySelector('.auth-card');
  if (authCard) {
    anime({
      targets: authCard,
      scale: [0.88, 1],
      opacity: [0, 1],
      duration: 650,
      easing: 'easeOutCubic',
      delay: 120,
    });
  }


  // ─── Sidebar Slide-In ──────────────────────────────────────────────────
  const sidebar = document.querySelector('.sidebar');
  if (sidebar) {
    anime({
      targets: sidebar,
      translateX: [-24, 0],
      opacity: [0, 1],
      duration: 650,
      easing: 'easeOutCubic',
      delay: 100,
    });
  }


  // ─── Page Heading + Composer — Feed Entrance ────────────────────────────
  const feedIntro = document.querySelectorAll('.page-heading, .composer');
  if (feedIntro.length) {
    anime({
      targets: feedIntro,
      translateY: [26, 0],
      opacity: [0, 1],
      duration: 700,
      delay: anime.stagger(120, { start: 160 }),
      easing: 'easeOutCubic',
    });
  }


  // ─── Profile Hero Entrance ──────────────────────────────────────────────
  const profileHero = document.querySelector('.profile-hero');
  if (profileHero) {
    anime({
      targets: profileHero,
      translateY: [32, 0],
      opacity: [0, 1],
      duration: 700,
      easing: 'easeOutCubic',
      delay: 100,
    });
  }


  // ─── Footer Fade ───────────────────────────────────────────────────────
  anime({
    targets: '.footer',
    opacity: [0, 1],
    duration: 800,
    easing: 'easeOutCubic',
    delay: 650,
  });


  // ─── Scroll-Triggered Animations (IntersectionObserver + anime.js) ─────
  const scrollEls = document.querySelectorAll('[data-animate]');
  if (scrollEls.length && 'IntersectionObserver' in window) {
    // Set initial hidden state
    scrollEls.forEach((el) => {
      el.style.opacity = '0';
      el.style.transform = 'translateY(28px)';
    });

    const observer = new IntersectionObserver(
      (entries) => {
        const revealed = entries
          .filter((e) => e.isIntersecting)
          .map((e) => {
            observer.unobserve(e.target);
            return e.target;
          });

        if (revealed.length) {
          anime({
            targets: revealed,
            translateY: [28, 0],
            opacity: [0, 1],
            duration: 700,
            delay: anime.stagger(70),
            easing: 'easeOutCubic',
          });
        }
      },
      { threshold: 0.06, rootMargin: '0px 0px -30px 0px' }
    );

    scrollEls.forEach((el) => observer.observe(el));
  } else {
    // Fallback: show everything
    scrollEls.forEach((el) => {
      el.style.opacity = '1';
      el.style.transform = 'none';
    });
  }


  // ─── Character Counters with Color States ──────────────────────────────
  document.querySelectorAll('textarea[maxlength]').forEach((field) => {
    if (field.type === 'hidden') return;

    const counter = document.createElement('div');
    counter.className = 'char-counter';
    counter.setAttribute('aria-live', 'polite');
    field.insertAdjacentElement('afterend', counter);

    const max = parseInt(field.maxLength, 10);
    const update = () => {
      const len = field.value.length;
      counter.textContent = `${len} / ${max}`;
      counter.classList.remove('warning', 'danger');
      if (max - len <= Math.floor(max * 0.05)) counter.classList.add('danger');
      else if (max - len <= Math.floor(max * 0.2)) counter.classList.add('warning');
    };
    field.addEventListener('input', update);
    update();
  });


  // ─── Topbar Shadow on Scroll ────────────────────────────────────────────
  const topbar = document.querySelector('.topbar');
  if (topbar) {
    let ticking = false;
    window.addEventListener(
      'scroll',
      () => {
        if (!ticking) {
          requestAnimationFrame(() => {
            topbar.classList.toggle('scrolled', window.scrollY > 12);
            ticking = false;
          });
          ticking = true;
        }
      },
      { passive: true }
    );
  }


  // ─── Flash Messages (anime.js entrance + auto-dismiss) ─────────────────
  const flashes = document.querySelectorAll('.flash');
  if (flashes.length) {
    anime({
      targets: flashes,
      translateX: [-28, 0],
      opacity: [0, 1],
      duration: 500,
      delay: anime.stagger(90),
      easing: 'easeOutCubic',
    });

    flashes.forEach((flash, i) => {
      flash.addEventListener('click', () => dismissFlash(flash));
      setTimeout(() => {
        if (flash.isConnected) dismissFlash(flash);
      }, 5500 + i * 700);
    });
  }

  function dismissFlash(el) {
    if (el.dataset.dismissing) return;
    el.dataset.dismissing = 'true';
    anime({
      targets: el,
      translateX: [0, 40],
      opacity: [1, 0],
      maxHeight: [el.offsetHeight, 0],
      marginBottom: [8, 0],
      paddingTop: { value: 0, duration: 300, delay: 100 },
      paddingBottom: { value: 0, duration: 300, delay: 100 },
      duration: 400,
      easing: 'easeInCubic',
      complete: () => el.remove(),
    });
  }


  // ─── Like Button Heart Pop ──────────────────────────────────────────────
  document.querySelectorAll('.post-actions form .action-button').forEach((btn) => {
    btn.addEventListener('click', function () {
      anime({
        targets: this,
        scale: [1, 1.4, 0.9, 1.15, 1],
        duration: 550,
        easing: 'easeOutElastic(1, 0.5)',
      });
    });
  });


  // ─── Primary Button Ripple ──────────────────────────────────────────────
  document.querySelectorAll('.button.primary').forEach((btn) => {
    btn.addEventListener('click', function (e) {
      const ripple = document.createElement('span');
      ripple.className = 'ripple';
      const rect = this.getBoundingClientRect();
      const size = Math.max(rect.width, rect.height);
      ripple.style.width = ripple.style.height = size + 'px';
      ripple.style.left = e.clientX - rect.left - size / 2 + 'px';
      ripple.style.top = e.clientY - rect.top - size / 2 + 'px';
      this.appendChild(ripple);

      anime({
        targets: ripple,
        scale: [0, 4],
        opacity: [0.4, 0],
        duration: 600,
        easing: 'easeOutCubic',
        complete: () => ripple.remove(),
      });
    });
  });


  // ─── Feature Card Icon Hover (anime.js) ─────────────────────────────────
  document.querySelectorAll('.feature-card').forEach((card) => {
    const icon = card.querySelector('.feature-icon');
    if (!icon) return;

    card.addEventListener('mouseenter', () => {
      anime({
        targets: icon,
        scale: 1.18,
        rotate: 8,
        duration: 400,
        easing: 'easeOutCubic',
      });
    });
    card.addEventListener('mouseleave', () => {
      anime({
        targets: icon,
        scale: 1,
        rotate: 0,
        duration: 400,
        easing: 'easeOutCubic',
      });
    });
  });


  // ─── Stat Card Count-Up ─────────────────────────────────────────────────
  document.querySelectorAll('.stat strong').forEach((el) => {
    const target = parseInt(el.textContent, 10);
    if (isNaN(target) || target <= 0) return;

    const obj = { val: 0 };
    const countObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            countObserver.unobserve(entry.target);
            anime({
              targets: obj,
              val: target,
              round: 1,
              duration: Math.min(800 + target * 10, 2000),
              easing: 'easeOutCubic',
              update: () => {
                el.textContent = obj.val;
              },
            });
          }
        });
      },
      { threshold: 0.5 }
    );
    countObserver.observe(el);
  });


  // ─── Smooth Composer Focus ──────────────────────────────────────────────
  const composerTA = document.querySelector('.composer textarea');
  if (composerTA) {
    composerTA.addEventListener('focus', () => {
      composerTA.closest('.composer')?.scrollIntoView({
        behavior: 'smooth',
        block: 'nearest',
      });
    });
  }

});

# Vibe Social App — Version 1

A beginner-friendly, database-backed social community app built with Python (Flask), SQLite, HTML, CSS and JavaScript.

## Features in this first version

- Account registration and login (passwords are hashed, never stored as plain text)
- Logout and session-based authentication
- SQLite database for users, posts, likes and comments
- Create text posts in the community feed
- Like/unlike posts
- Add comments to posts
- Basic profile page with your posts and like count
- Responsive layout for desktop and mobile
- CSRF tokens on forms and parameterized SQL queries

## Run it on Windows

1. Install Python 3.10 or newer from the official Python website.
2. Extract this folder somewhere easy to find.
3. Open Command Prompt or the VS Code terminal in this folder.
4. Create a virtual environment:

   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```

5. Install the dependency:

   ```powershell
   python -m pip install -r requirements.txt
   ```

6. Start the app:

   ```powershell
   python app.py
   ```

7. Open `http://127.0.0.1:5000` in your browser and register an account.

The SQLite database (`vibe.db`) is created automatically the first time the app starts.

## Important security notes

This is a learning/MVP project, not yet ready for public production deployment. Before deploying publicly:

- Set a strong random `VIBE_SECRET_KEY` environment variable; do not use the development fallback.
- Set `VIBE_HTTPS=1` only when HTTPS is correctly configured.
- Turn off debug mode (it is off by default).
- Add email verification, password reset, rate limiting, account moderation, backups, logging and deployment-specific security controls.
- Configure a production WSGI server and HTTPS reverse proxy.
- Do not collect sensitive personal information until the app's privacy and security requirements are addressed.

## Next features to build

1. Email verification and password reset
2. Profile editing and avatar upload
3. Image posts and safe media storage
4. Follow/unfollow and a personalized feed
5. Notifications
6. Private messaging
7. Automated tests and deployment
